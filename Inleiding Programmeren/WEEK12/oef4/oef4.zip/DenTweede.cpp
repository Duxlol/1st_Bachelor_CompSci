#include "DenTweede.h"

DenTweede::DenTweede() {
    cout << "1, ";  // Constructor prints 1
}

DenTweede::~DenTweede() {
    cout << "8.";  // Destructor prints 8
}
