#ifndef DENDERDE_H
#define DENDERDE_H

#include <iostream>
using namespace std;

class DenDerde {
public:
    DenDerde();  // Constructor
    ~DenDerde();  // Destructor
};

#endif // DENDERDE_H
