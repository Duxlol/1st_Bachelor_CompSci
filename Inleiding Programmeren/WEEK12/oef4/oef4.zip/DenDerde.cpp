#include "DenDerde.h"

DenDerde::DenDerde() {
    cout << "3, ";  // Constructor prints 4
}

DenDerde::~DenDerde() {
    cout << "5, ";  // Destructor prints 5
}
