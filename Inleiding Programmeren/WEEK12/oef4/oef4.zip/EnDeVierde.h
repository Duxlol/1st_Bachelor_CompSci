#ifndef ENDEVIERDE_H
#define ENDEVIERDE_H

#include <iostream>
using namespace std;

class EnDeVierde {
public:
    EnDeVierde();  // Constructor
    ~EnDeVierde();  // Destructor
};

#endif // ENDEVIERDE_H
