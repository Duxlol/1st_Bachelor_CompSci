#ifndef DENTWEEDE_H
#define DENTWEEDE_H

#include <iostream>
using namespace std;

class DenTweede {
public:
    DenTweede();  // Constructor
    virtual ~DenTweede();  // Destructor
};

#endif // DENTWEEDE_H
