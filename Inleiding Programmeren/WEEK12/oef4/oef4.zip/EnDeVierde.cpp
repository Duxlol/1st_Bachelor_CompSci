#include "EnDeVierde.h"

EnDeVierde::EnDeVierde() {
    cout << "2, ";  // Constructor prints 2
}

EnDeVierde::~EnDeVierde() {
    cout << "7, ";  // Destructor prints 7
}
