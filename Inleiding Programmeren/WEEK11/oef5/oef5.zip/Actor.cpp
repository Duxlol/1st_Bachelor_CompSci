#include "Actor.h"
using namespace std;

Actor::Actor(const string &firstname, const string &lastname)
        : firstname(firstname),
          lastname(lastname) {
}