#include "Director.h"
using namespace std;

Director::Director(const string &firstname, const string &lastname)
        : firstname(firstname),
          lastname(lastname) {
}